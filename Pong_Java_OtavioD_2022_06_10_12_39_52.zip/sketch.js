//kkkjogomerdakappa
let xBolinha =300;
let yBolinha =200;
let diametro =15;
let velocidadeXbolinha =6;
let velocidadeYbolinha =6;
let raio =diametro / 2

//raquete...sóqnãotempiadaaqui:C
let xRaquete =5;
let yRaquete =150;
let raquetecomprimento =10;
let raquetealtura =90;

//variaveisoponentekkkfodasi
let xRaqueteoponente = 585;
let yRaqueteoponente = 150;
let velocidadeYoponente;

//pontosahquemerda
let meuspontos = 0;
let pontosoponente = 0;

//sonsmaneirosefodas
let raquetada;
let ponto;
let trilha

function preload(){
  trilha = loadSound("Pokemon Emerald Soundtrack _5 - Littleroot Town(MP3_320K).mp3");
  ponto = loadSound("Cavalo vinhetas(MP3_160K).mp3")
  raquetada = loadSound("bola de ténis de ser atingido um.wav");
}


let hit = false;

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentosexykkkj();
  verificacolisãokkkjseilagaraio();
  mostraraqueteaaaaa(xRaquete, yRaquete);
  mostraraqueteaaaaa(xRaqueteoponente, yRaqueteoponente);
  movimentosexydaraquete();
  //verificacolisãohauuu();
  colisao_0(xRaquete,yRaquete);
  movimentaraqueteoponente();
  colisao_0(xRaqueteoponente, yRaqueteoponente)
  incluiplacar();
  marcaponto();
   bolinhaNaoFicaPresa();
}

function mostraBolinha(){100
  circle(xBolinha, yBolinha, diametro);
                        }

function movimentosexykkkj(){
  
 xBolinha += velocidadeXbolinha
  yBolinha += velocidadeYbolinha
  
}100

function verificacolisãokkkjseilagaraio(){
   if (xBolinha + raio> width ||
     xBolinha - raio< 0){
    velocidadeXbolinha *=-1;
  }
  
  if (yBolinha + raio> height ||
     yBolinha - raio< 0){
    velocidadeYbolinha *=-1
  }
  
}

function mostraraqueteaaaaa(x, y){
  rect(x, y, raquetecomprimento, 
       raquetealtura);

}


function movimentosexydaraquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -=10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete +=10;
  }
}
function movimentaraqueteoponente(){
  if (keyIsDown(87)){
    yRaqueteoponente -=10;
  }
  if (keyIsDown(83)){
    yRaqueteoponente +=10;
  }
}

function verificacolisãohauuu(){
  if (xBolinha - raio < xRaquete + raquetecomprimento 
&& yBolinha - raio < yRaquete + raquetealtura && yBolinha + raio > yRaquete){
  velocidadeXbolinha *= -1;  
    raquetada.play();
  }
}
function colisao_0(x,y){
 hit = 
  collideRectCircle(x, y, raquetecomprimento, raquetealtura, xBolinha, yBolinha, raio);
  if(hit){
    velocidadeXbolinha *= -1;  
    raquetada.play();
  }
}
function incluiplacar(){
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0));
  rect(150, 10, 40, 20);
  fill(255);
  text(meuspontos, 170, 26);
  fill(color(255, 140, 0))
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosoponente, 470, 26);
}
function marcaponto(){
if (xBolinha > 590){
  meuspontos += 1;
  ponto.play();
}
  if (xBolinha < 10){
    pontosoponente += 1;
    ponto.play();
  }
}
function bolinhaNaoFicaPresa(){
    if (xBolinha - raio < 0){
    xBolinha = 23
    }
}